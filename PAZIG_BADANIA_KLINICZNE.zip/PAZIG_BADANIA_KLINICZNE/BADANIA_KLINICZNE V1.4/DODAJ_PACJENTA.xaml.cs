﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using System.Data;

namespace BADANIA_KLINICZNE_V1._4
{
    /// <summary>
    /// Logika interakcji dla klasy DODAJ_PACJENTA.xaml
    /// </summary>
    public partial class DODAJ_PACJENTA : Page
    {

        public string dodaj_imiona;
        public string dodaj_nazwisko;
        public string dodaj_pesel;
        public string dodaj_miasto;
        public string dodaj_kod_poczty;
        public string dodaj_ulice;
        public string dodaj_nr_budynku;
        public string dodaj_nr_lokalu;
        public string dodaj_nr_telefonu;
        public string dodaj_alergia;
        public string dodaj_choroby_przebyte;
        public string dodaj_grupa_krwi;
        public string dodaj_czynnik_rh;
        public string cmd_dodaj;

        MainWindow m = new MainWindow();


        public DODAJ_PACJENTA()
        {
            InitializeComponent();
        }


        public void Dodaj_Pacjenta()
        {
            dodaj_nazwisko = TxT_nazwisko.Text.ToUpper();
            dodaj_imiona = TxT_imiona.Text.ToUpper();
            dodaj_pesel = TxT_pesel.Text.ToUpper();
            dodaj_miasto = TxT_miasto.Text.ToUpper();
            dodaj_kod_poczty = TxT_kod_pocztowy.Text.ToUpper();
            dodaj_ulice = TxT_ulica.Text.ToUpper();
            dodaj_nr_budynku = TxT_nr_budynku.Text.ToUpper();
            dodaj_nr_lokalu = TxT_nr_lokalu.Text.ToUpper();
            dodaj_nr_telefonu = TxT_telefon.Text.ToUpper();
            dodaj_alergia = TxT_alergie.Text.ToUpper();
            dodaj_choroby_przebyte = TxT_przebyte_choroby.Text.ToUpper();
            dodaj_grupa_krwi = CbX_grupa.Text;
            dodaj_czynnik_rh = CbX_czynnik_rh.Text;
            cmd_dodaj = string.Format("INSERT INTO `pacjent` (`PAC_ID`, `NAZWISKO`, `IMIONA`, `PESEL`, `MIASTO`, `KOD_POCZT`, `ULICA`, `NR_BUD`, `NR_LOK`, `NR_TELEFONU`, `ALERGIE`, `PRZEBYTE_CHOROBY`, `GRUPA_KRWI`, `CZYNNIK_RH`) " +
                "VALUES((SELECT nvl((MAX(PAC_ID)+1),'1') FROM `pacjent`  pac), '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}');"
                , dodaj_nazwisko, dodaj_imiona, dodaj_pesel, dodaj_miasto, dodaj_kod_poczty, dodaj_ulice, dodaj_nr_budynku, dodaj_nr_lokalu, dodaj_nr_telefonu, dodaj_alergia, dodaj_choroby_przebyte,dodaj_grupa_krwi,dodaj_czynnik_rh);
            MySqlCommand cmd2 = new MySqlCommand(cmd_dodaj, m.con);
            cmd2.ExecuteNonQuery();
        }
        public void Czyszczenie_Pol_Pacjenta()
        {
            TxT_nazwisko.Text = "";
            TxT_imiona.Text = "";
            TxT_pesel.Text = "";
            TxT_miasto.Text = "";
            TxT_kod_pocztowy.Text = "";
            TxT_ulica.Text = "";
            TxT_nr_budynku.Text = "";
            TxT_nr_lokalu.Text = "";
            TxT_telefon.Text = "";
            TxT_alergie.Text = "";
            TxT_przebyte_choroby.Text = "";
            CbX_grupa.Text = "";
            CbX_czynnik_rh.Text = "";
        }
            private void BtN_zapisz_dane_pac_Click(object sender, RoutedEventArgs e)
        {
            Dodaj_Pacjenta();
            Czyszczenie_Pol_Pacjenta();
            MessageBox.Show("Poprawnie dodane dane pacjenta.");
        }

    }
}
