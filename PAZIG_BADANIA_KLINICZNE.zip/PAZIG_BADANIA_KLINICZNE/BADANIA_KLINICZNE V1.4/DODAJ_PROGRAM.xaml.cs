﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using System.Data;

namespace BADANIA_KLINICZNE_V1._4
{
    /// <summary>
    /// Logika interakcji dla klasy DODAJ_PROGRAM.xaml
    /// </summary>
    public partial class DODAJ_PROGRAM : Page
    {
        MainWindow m = new MainWindow();
        public string program_nazwa;
        public string program_opis;
        public string program_data_start;
        public string program_data_stop;
        public int program_ilosc_osob;
        public string kod_lub_nazwa_leku;
        public string kod_lub_nazwa_pomiaru;
        public string lek_kod;
        public string pom_kod;
        public string lek_kod_w_programie;
        public string pom_kod_w_programie;
        public int prog_id;
        public string cmd_zapisz_program;
        public string cmd_szukaj_programy;
        public string cmd_szukaj_globalny_slownik_lekow;
        public string cmd_dodaj_lek_do_programu;
        public string cmd_szukaj_leki_programu;
        public string cmd_usun_lek_w_programie;
        public string cmd_szukaj_globalny_slownik_pomiarow;
        public string cmd_dodaj_pomiar_do_programu;
        public string cmd_szukaj_pomiary_programu;
        public string cmd_usun_pomiar_w_programie;
        public string cmd_program_id;
        public string cmd_program_opis;
        public string cmd_program_data_od;
        public string cmd_program_data_do;
        public string cmd_program_ilosc_osob;




        public DODAJ_PROGRAM()
        {
            InitializeComponent();
            Wczytaj_Programy();
            dezaktywacja_pol();
            

            
            
        }

        public void dezaktywacja_pol()
        {
            TxT_nazwa_programu.IsEnabled = false;
            TxT_opis_programu.IsEnabled = false;
            DATA_DO.IsEnabled = false;
            DATA_OD.IsEnabled = false;
            TxT_ILOSC_OSOB_W_PROGRAMIE.IsEnabled = false;
            BtN_ZAPISZ_PROGRAM.IsEnabled = false;

            SLOWNIK_LEKOW.IsEnabled = true;
            LEKI_W_PROGRAMIE.IsEnabled = true;
            TxT_KOD_LUB_NAZWA_LEKU.IsEnabled = true;
            DODAJ_LEK_DO_PROGRAMU.IsEnabled = true;
            USUŃ_LEK_Z_PROGRAMU.IsEnabled = true;
            USUŃ_LEK_Z_PROGRAMU_2.IsEnabled = true;

            SLOWNIK_POMIAROW.IsEnabled = true;
            POMIARY_W_PROGRAMIE.IsEnabled = true;
            TxT_KOD_LUB_NAZWA_POMIARU.IsEnabled = true;
            DODAJ_POMIAR_DO_PROGRAMU.IsEnabled = true;
            USUŃ_POMIAR_Z_PROGRAMU.IsEnabled = true;
            USUŃ_POMIAR_Z_PROGRAMU_2.IsEnabled = true;
        }

        public void aktywacja_pol()
        {
            TxT_nazwa_programu.IsEnabled = true;
            TxT_opis_programu.IsEnabled = true;
            DATA_DO.IsEnabled = true;
            DATA_OD.IsEnabled = true;
            TxT_ILOSC_OSOB_W_PROGRAMIE.IsEnabled = true;
            BtN_ZAPISZ_PROGRAM.IsEnabled = true;
            TxT_nazwa_programu.Text = "";
            TxT_opis_programu.Text = "";
            DATA_DO.Text = "";
            DATA_OD.Text = "";
            TxT_ILOSC_OSOB_W_PROGRAMIE.Text=""; 

            SLOWNIK_LEKOW.IsEnabled = false;
            LEKI_W_PROGRAMIE.IsEnabled = false;
            TxT_KOD_LUB_NAZWA_LEKU.IsEnabled = false;
            DODAJ_LEK_DO_PROGRAMU.IsEnabled = false;
            USUŃ_LEK_Z_PROGRAMU.IsEnabled = false;
            USUŃ_LEK_Z_PROGRAMU_2.IsEnabled = false;

            SLOWNIK_POMIAROW.IsEnabled = false;
            POMIARY_W_PROGRAMIE.IsEnabled = false;
            TxT_KOD_LUB_NAZWA_POMIARU.IsEnabled = false;
            DODAJ_POMIAR_DO_PROGRAMU.IsEnabled = false;
            USUŃ_POMIAR_Z_PROGRAMU.IsEnabled = false;
            USUŃ_POMIAR_Z_PROGRAMU_2.IsEnabled = false;


        }
        public void Wczytaj_Programy()
        {
            CbX_PROGRAMY.Items.Clear();
            cmd_szukaj_programy = "SELECT NAZWA_PROG FROM `program` order by prog_id desc;";
            DataTable Slownik = new DataTable();
            MySqlCommand cmd = new MySqlCommand(cmd_szukaj_programy, m.con);
            MySqlDataReader czytnik = cmd.ExecuteReader();
            while (czytnik.Read())
            {
                string programy = czytnik.GetString(0);
                CbX_PROGRAMY.Items.Add(programy);
                
            }
            czytnik.Close();
            CbX_PROGRAMY.SelectedIndex = 0;


        }

        public void Wybrany_program()
        {
            program_nazwa = CbX_PROGRAMY.Text;
            cmd_program_id = string.Format("SELECT PROG_ID FROM `program` WHERE NAZWA_PROG = '{0}';", program_nazwa);
            cmd_program_opis = string.Format("SELECT OPIS_PROGRAMU FROM `program` WHERE NAZWA_PROG = '{0}';", program_nazwa);
            cmd_program_data_od = string.Format("SELECT DATA_ROZP FROM `program` WHERE NAZWA_PROG = '{0}';", program_nazwa);
            cmd_program_data_do = string.Format("SELECT DATA_ZAK FROM `program` WHERE NAZWA_PROG = '{0}';", program_nazwa);
            cmd_program_ilosc_osob = string.Format("SELECT IL_OSOB FROM `program` WHERE NAZWA_PROG = '{0}';", program_nazwa);
            MySqlCommand cmd_pr_id = new MySqlCommand(cmd_program_id, m.con);
            MySqlCommand cmd_pr_op = new MySqlCommand(cmd_program_opis, m.con);
            MySqlCommand cmd_pr_dt_od = new MySqlCommand(cmd_program_data_od, m.con);
            MySqlCommand cmd_pr_dt_do = new MySqlCommand(cmd_program_data_do, m.con);
            MySqlCommand cmd_pr_il_os = new MySqlCommand(cmd_program_ilosc_osob, m.con);
            prog_id = (int)cmd_pr_id.ExecuteScalar();
            program_opis = (string)cmd_pr_op.ExecuteScalar();
            program_data_start = ((DateTime)cmd_pr_dt_od.ExecuteScalar()).ToString();
            program_data_stop = ((DateTime)cmd_pr_dt_do.ExecuteScalar()).ToString();
            program_ilosc_osob = (int)cmd_pr_il_os.ExecuteScalar();
            TxT_nazwa_programu.Text = program_nazwa;
            TxT_opis_programu.Text = program_opis.ToString();
            DATA_OD.Text = program_data_start;
            DATA_DO.Text = program_data_stop;
            TxT_ILOSC_OSOB_W_PROGRAMIE.Text = program_ilosc_osob.ToString();

        }

       
        public void zapisanie_programu()
        {
            program_nazwa = TxT_nazwa_programu.Text.ToUpper();
            program_opis = TxT_opis_programu.Text;
            program_data_start = DATA_OD.ToString();
            program_data_stop = DATA_DO.ToString();
            program_ilosc_osob = int.Parse(TxT_ILOSC_OSOB_W_PROGRAMIE.Text);
            cmd_zapisz_program = string.Format("INSERT INTO `program`(`PROG_ID`, `NAZWA_PROG`, `OPIS_PROGRAMU`, `DATA_ROZP`, `DATA_ZAK`, `IL_OSOB`) VALUES ((SELECT nvl((MAX(PROG_ID)+1),'1') FROM `program`  prog),'{0}','{1}','{2}','{3}','{4}')", program_nazwa,program_opis,program_data_start,program_data_stop, program_ilosc_osob );
            MySqlCommand cmd = new MySqlCommand(cmd_zapisz_program, m.con);
            cmd.ExecuteNonQuery();
            
        }

        private void Wczytaj_Globalny_Slownik_Lekow()
        {
            kod_lub_nazwa_leku = "%" + TxT_KOD_LUB_NAZWA_LEKU.Text.ToUpper() + "%";
            cmd_szukaj_globalny_slownik_lekow = string.Format("SELECT LEK_KOD as \"KOD\", NAZWA_LEK as \"NAZWA LEKU\"  FROM sl_leki WHERE (LEK_KOD LIKE '{0}' or NAZWA_LEK like '{0}') and lek_id not in (select lek_id from program_leki where prog_id = '{1}');", kod_lub_nazwa_leku, prog_id);
            DataTable Slownik = new DataTable(); //("SELECT LEK_KOD as \"KOD\", NAZWA_LEK as \"NAZWA LEKU\"  FROM sl_leki WHERE LEK_KOD LIKE '{0}' or NAZWA_LEK like '{0}';", kod_lub_nazwa_leku)
            MySqlCommand cmd = new MySqlCommand(cmd_szukaj_globalny_slownik_lekow, m.con);
            MySqlDataReader czytnik = cmd.ExecuteReader();
            Slownik.Load(czytnik);
            SLOWNIK_LEKOW.ItemsSource = Slownik.DefaultView;
        }
        private void TxT_KOD_LUB_NAZWA_LEKU_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                kod_lub_nazwa_leku = TxT_KOD_LUB_NAZWA_LEKU.Text.ToUpper();
                Wczytaj_Globalny_Slownik_Lekow();

            }
        }

        private void Dodaj_Leki_Do_Programu()
        {

            DataRowView numer_wiersza_slownik_lekow = (DataRowView)SLOWNIK_LEKOW.SelectedItem;
            lek_kod = numer_wiersza_slownik_lekow.Row.ItemArray[0].ToString();
            cmd_dodaj_lek_do_programu = string.Format("INSERT INTO `program_leki`(`PROG_ID`, `LEK_ID`) VALUES('{0}', (select LEK_ID from sl_leki lek WHERE lek_kod = '{1}'));", prog_id, lek_kod );
            MySqlCommand cmd = new MySqlCommand(cmd_dodaj_lek_do_programu, m.con);
            cmd.ExecuteNonQuery();
        }

        public void Wczytaj_Leki_Programu()
        {
            cmd_szukaj_leki_programu = string.Format("select LEK_KOD as \"KOD\", NAZWA_LEK as \"NAZWA LEKU\" from sl_leki where LEK_ID in (select lek_id from program_leki where prog_id = '{0}');", prog_id);
            DataTable Slownik = new DataTable();
            MySqlCommand cmd = new MySqlCommand(cmd_szukaj_leki_programu, m.con);
            MySqlDataReader czytnik = cmd.ExecuteReader();
            Slownik.Load(czytnik);
            LEKI_W_PROGRAMIE.ItemsSource = Slownik.DefaultView;
        }

        public void Usuń_Leki_Programu()
        {
            DataRowView numer_wiersza_lekow_programu = (DataRowView)LEKI_W_PROGRAMIE.SelectedItem;
            lek_kod_w_programie = numer_wiersza_lekow_programu.Row.ItemArray[0].ToString();
            cmd_usun_lek_w_programie = string.Format("DELETE FROM `program_leki` WHERE PROG_ID = '{0}' and LEK_ID = (select LEK_ID FROM sl_leki where lek_kod = '{1}')", prog_id, lek_kod_w_programie);
            MySqlCommand cmd = new MySqlCommand(cmd_usun_lek_w_programie, m.con);
            cmd.ExecuteNonQuery();
        }

        private void Wczytaj_Globalny_Slownik_Pomiarow()
        {
            kod_lub_nazwa_pomiaru = "%" + TxT_KOD_LUB_NAZWA_POMIARU.Text.ToUpper() + "%";
            cmd_szukaj_globalny_slownik_pomiarow = string.Format("SELECT POM_KOD as \"KOD\", NAZWA_POM as \"NAZWA POMIARU\", JEDNOSTKA_POM as \"JEDNOSTKA\" FROM sl_pomiary WHERE (NAZWA_POM like '{0}' or POM_KOD LIKE '{0}') and pom_id not in (select pom_id from program_pomiary where prog_id = '{1}');", kod_lub_nazwa_pomiaru, prog_id);
            DataTable Slownik = new DataTable();
            MySqlCommand cmd = new MySqlCommand(cmd_szukaj_globalny_slownik_pomiarow, m.con);
            MySqlDataReader czytnik = cmd.ExecuteReader();
            Slownik.Load(czytnik);
            SLOWNIK_POMIAROW.ItemsSource = Slownik.DefaultView;
        }

        private void TxT_KOD_LUB_NAZWA_POMIARU_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                kod_lub_nazwa_pomiaru = TxT_KOD_LUB_NAZWA_POMIARU.Text.ToUpper();
                Wczytaj_Globalny_Slownik_Pomiarow();

            }
        }

        private void Dodaj_Pomiary_Do_Programu()
        {

            DataRowView numer_wiersza_slownik_pomiarow = (DataRowView)SLOWNIK_POMIAROW.SelectedItem;
            pom_kod = numer_wiersza_slownik_pomiarow.Row.ItemArray[0].ToString();
            cmd_dodaj_pomiar_do_programu = string.Format("INSERT INTO `program_pomiary`(`PROG_ID`, `POM_ID`) VALUES('{0}', (select POM_ID from sl_pomiary pom WHERE POM_KOD = '{1}'));", prog_id, pom_kod);
            MySqlCommand cmd = new MySqlCommand(cmd_dodaj_pomiar_do_programu, m.con);
            cmd.ExecuteNonQuery();
        }

        public void Wczytaj_Pomiary_Programu()
        {
            cmd_szukaj_pomiary_programu = string.Format("select POM_KOD as \"KOD\", NAZWA_POM as \"NAZWA POMIARU\" from sl_pomiary where POM_ID in (select POM_ID from program_pomiary where prog_id = '{0}');", prog_id);
            DataTable Slownik = new DataTable();
            MySqlCommand cmd = new MySqlCommand(cmd_szukaj_pomiary_programu, m.con);
            MySqlDataReader czytnik = cmd.ExecuteReader();
            Slownik.Load(czytnik);
            POMIARY_W_PROGRAMIE.ItemsSource = Slownik.DefaultView;
        }

        public void Usuń_Pomiary_Programu()
        {
            DataRowView numer_wiersza_pomiaru_programu = (DataRowView)POMIARY_W_PROGRAMIE.SelectedItem;
            pom_kod_w_programie = numer_wiersza_pomiaru_programu.Row.ItemArray[0].ToString();
            cmd_usun_pomiar_w_programie = string.Format("DELETE FROM `program_pomiary` WHERE PROG_ID = '{0}' and POM_ID = (select POM_ID FROM sl_pomiary where pom_kod = '{1}')", prog_id, pom_kod_w_programie);
            MySqlCommand cmd = new MySqlCommand(cmd_usun_pomiar_w_programie, m.con);
            cmd.ExecuteNonQuery();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            zapisanie_programu();
            Wczytaj_Programy();
            Wybrany_program();
            Wczytaj_Globalny_Slownik_Lekow();
            Wczytaj_Leki_Programu();
            Wczytaj_Globalny_Slownik_Pomiarow();
            Wczytaj_Pomiary_Programu();
            dezaktywacja_pol();
        }

        private void DODAJ_LEK_DO_PROGRAMU_Click(object sender, RoutedEventArgs e)
        {
            if (SLOWNIK_LEKOW.SelectedIndex > -1)
            {
                Dodaj_Leki_Do_Programu();
                Wczytaj_Leki_Programu();
                Wczytaj_Globalny_Slownik_Lekow();
            }
            
        }

        private void USUŃ_LEK_Z_PROGRAMU_Click(object sender, RoutedEventArgs e)
        {
            if (LEKI_W_PROGRAMIE.SelectedIndex > -1)
            {
                Usuń_Leki_Programu();
                Wczytaj_Leki_Programu();
                Wczytaj_Globalny_Slownik_Lekow();
            }
            
        }

        private void USUŃ_LEK_Z_PROGRAMU_2_Click(object sender, RoutedEventArgs e)
        {
            if (LEKI_W_PROGRAMIE.SelectedIndex > -1)
            {
                Usuń_Leki_Programu();
                Wczytaj_Leki_Programu();
                Wczytaj_Globalny_Slownik_Lekow();
            }
        }

        private void DODAJ_POMIAR_DO_PROGRAMU_Click(object sender, RoutedEventArgs e)
        {

            if (SLOWNIK_POMIAROW.SelectedIndex > -1)
            {
                Dodaj_Pomiary_Do_Programu();
                Wczytaj_Pomiary_Programu();
                Wczytaj_Globalny_Slownik_Pomiarow();
            }
           
        }

        private void USUŃ_POMIAR_Z_PROGRAMU_Click(object sender, RoutedEventArgs e)
        {

            if (POMIARY_W_PROGRAMIE.SelectedIndex > -1)
            {
                Usuń_Pomiary_Programu();
                Wczytaj_Pomiary_Programu();
                Wczytaj_Globalny_Slownik_Pomiarow();
            }

            

        }


        private void USUŃ_POMIAR_Z_PROGRAMU_2_Click(object sender, RoutedEventArgs e)
        {
            if (POMIARY_W_PROGRAMIE.SelectedIndex > -1)
            {
                Usuń_Pomiary_Programu();
                Wczytaj_Pomiary_Programu();
                Wczytaj_Globalny_Slownik_Pomiarow();
            }
        }

        private void WYBIERZ_PROGRAM_Click(object sender, RoutedEventArgs e)
        {
            dezaktywacja_pol();
            Wybrany_program();
            Wczytaj_Globalny_Slownik_Lekow();
            Wczytaj_Leki_Programu();
            Wczytaj_Globalny_Slownik_Pomiarow();
            Wczytaj_Pomiary_Programu();

        }

        private void DODAJ_NOWY_PROGRAM_Click(object sender, RoutedEventArgs e)
        {
            aktywacja_pol();
        }

    }
}
