﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using System.Data;

namespace BADANIA_KLINICZNE_V1._4
{
    /// <summary>
    /// Logika interakcji dla klasy DOPISZ_PACJENTA_DO_PROGRAMU.xaml
    /// </summary>
    public partial class DOPISZ_PACJENTA_DO_PROGRAMU : Page
    {

        MainWindow m = new MainWindow();
        public string cmd_szukaj_programy;
        public string program_nazwa_2;
        public string Pesel_Nazwisko_Imie;
        public string numer_wiersza_lista_pacjentow;
        public string cmd_szukaj_pacjenta;
        public string cmd_wyswietl_pacjentow_programu;
        public string pac_id;
        public int max_pac_w_programie;
        public int ile_pac_w_programie;
        public string cmd_dodaj_pacjenta_do_programu;
        public string cmd_szukaj_max_pac_w_prog;
        public string cmd_szukaj_ile_pac_w_prog;
        public string cmd_sprawdz_pac;
        public int czy_jest_pac_w_prog;
        public DOPISZ_PACJENTA_DO_PROGRAMU()
        {
            InitializeComponent();
            Wczytaj_Programy();
            Wyswietl_Pacjentów_Programu();
        }

        public void Wczytaj_Programy()
        {
            CbX_PROGRAMY.Items.Clear();
            cmd_szukaj_programy = "SELECT NAZWA_PROG FROM `program` order by prog_id desc;";
            DataTable Slownik = new DataTable();
            MySqlCommand cmd = new MySqlCommand(cmd_szukaj_programy, m.con);
            MySqlDataReader czytnik = cmd.ExecuteReader();
            while (czytnik.Read())
            {
                string programy = czytnik.GetString(0);
                CbX_PROGRAMY.Items.Add(programy);

            }
            czytnik.Close();
            CbX_PROGRAMY.SelectedIndex = 0;


        }

        public void Szukaj_Pacjenta()
        {
            Pesel_Nazwisko_Imie = "%" + TxT_Pesel_Imie_Nazwisko.Text.ToUpper() + "%";
            cmd_szukaj_pacjenta = string.Format("SELECT PAC_ID, NAZWISKO, IMIONA, PESEL  FROM `pacjent` WHERE  upper(NAZWISKO) like '{0}' or upper(IMIONA) like '{0}' or pesel like '{0}'; ", Pesel_Nazwisko_Imie);
            DataTable Slownik = new DataTable(); 
            MySqlCommand cmd = new MySqlCommand(cmd_szukaj_pacjenta, m.con);
            MySqlDataReader czytnik = cmd.ExecuteReader();
            Slownik.Load(czytnik);
            DG_Pacjenci.ItemsSource = Slownik.DefaultView;

        }

        public void Wyswietl_Pacjentów_Programu()
        {
            program_nazwa_2 = CbX_PROGRAMY.Text;
            cmd_wyswietl_pacjentow_programu = string.Format("SELECT PAC_NR as \"Nr Pacjenta\", (SELECT nazwisko from pacjent where PAC_ID=prg.PAC_ID) as \"Nazwisko\", (SELECT Imiona from pacjent where PAC_ID=prg.PAC_ID) as \"Imiona\", PLACEBO as \"Pacjent PLACEBO\", PROG_ID as \"Identyfikator Programu\" FROM pacjenci_programu prg where prg.prog_id in (select prog_id from program where NAZWA_PROG = '{0}'); ", program_nazwa_2);
            DataTable Slownik = new DataTable();
            MySqlCommand cmd = new MySqlCommand(cmd_wyswietl_pacjentow_programu, m.con);
            MySqlDataReader czytnik = cmd.ExecuteReader();
            Slownik.Load(czytnik);
            DG_Pacjenci_Programu.ItemsSource = Slownik.DefaultView;   
        }

        private void Dodaj_Pacjentów_Do_Programu()
        {
            program_nazwa_2 = CbX_PROGRAMY.Text;
            DataRowView numer_wiersza_lista_pacjentow = (DataRowView)DG_Pacjenci.SelectedItem;
            pac_id = numer_wiersza_lista_pacjentow.Row.ItemArray[0].ToString();
            cmd_dodaj_pacjenta_do_programu = string.Format("INSERT INTO `pacjenci_programu`(`PROG_ID`, `PAC_NR`, `PAC_ID`, `PLACEBO`) VALUES ((select prog_id from program where NAZWA_PROG = '{0}'),(SELECT nvl((MAX(PAC_NR)+1),'1') FROM `pacjenci_programu` pac_prog WHERE PROG_ID in (select prog_id from program where NAZWA_PROG = '{0}')),'{1}','{2}');", program_nazwa_2,pac_id,"NIE");
            MySqlCommand cmd = new MySqlCommand(cmd_dodaj_pacjenta_do_programu, m.con);
            cmd.ExecuteNonQuery();
        }

        public void Pobranie_PAC_ID_PROG_NAZWA()
        {
            if (DG_Pacjenci.SelectedItem != null)
            {
                program_nazwa_2 = CbX_PROGRAMY.Text;
                DataRowView numer_wiersza_lista_pacjentow = (DataRowView)DG_Pacjenci.SelectedItem;
                pac_id = numer_wiersza_lista_pacjentow.Row.ItemArray[0].ToString();
            }
            else { MessageBox.Show("Brak wybranego pacjenta dod dodania"); }
        }

        private void Dodaj_Pacjentów_Do_Programu_Placebo()
        {
            cmd_dodaj_pacjenta_do_programu = string.Format("INSERT INTO `pacjenci_programu`(`PROG_ID`, `PAC_NR`, `PAC_ID`, `PLACEBO`) VALUES ((select prog_id from program where NAZWA_PROG = '{0}'),(SELECT nvl((MAX(PAC_NR)+1),'1') FROM `pacjenci_programu` pac_prog WHERE PROG_ID in (select prog_id from program where NAZWA_PROG = '{0}')),'{1}','{2}');", program_nazwa_2, pac_id, "TAK");
            MySqlCommand cmd = new MySqlCommand(cmd_dodaj_pacjenta_do_programu, m.con);
            cmd.ExecuteNonQuery();
        }

        public void sprawdzenie_ilości_pacjentow_w_programie()
        {
            
            cmd_szukaj_max_pac_w_prog = string.Format("SELECT IL_OSOB FROM `program` where PROG_ID in (select prog_id from program where NAZWA_PROG = '{0}');", program_nazwa_2);
            cmd_szukaj_ile_pac_w_prog = string.Format("SELECT count(*) FROM `pacjenci_programu`  where PROG_ID in (select prog_id from program where NAZWA_PROG = '{0}');", program_nazwa_2);
            DataTable Slownik = new DataTable();
            MySqlCommand cmd_max_pac = new MySqlCommand(cmd_szukaj_max_pac_w_prog, m.con);
            MySqlCommand cmd_ile_pac = new MySqlCommand(cmd_szukaj_ile_pac_w_prog, m.con);
            max_pac_w_programie = (int)cmd_max_pac.ExecuteScalar();
            ile_pac_w_programie = int.Parse(cmd_ile_pac.ExecuteScalar().ToString());
            
        }

        public void sprawdzenie_pacjenta_w_programie()
        {

            cmd_sprawdz_pac = string.Format("SELECT count(*) FROM `pacjenci_programu`  where PAC_ID = '{0}' and PROG_ID in (select prog_id from program where NAZWA_PROG = '{1}');",pac_id ,program_nazwa_2);
            DataTable Slownik = new DataTable();
            MySqlCommand cmd_spr_pac = new MySqlCommand(cmd_sprawdz_pac, m.con);
            czy_jest_pac_w_prog = int.Parse(cmd_spr_pac.ExecuteScalar().ToString());
            
        }


        private void BtN_Szukaj_Pacjenta_Click(object sender, RoutedEventArgs e)
        {
            Szukaj_Pacjenta();
        }

        private void BtN_Dodaj_Pacjenta_Do_Programu_Click(object sender, RoutedEventArgs e)
        {
            sprawdzenie_ilości_pacjentow_w_programie();
            if (ile_pac_w_programie<max_pac_w_programie)
            {
                Pobranie_PAC_ID_PROG_NAZWA();
                sprawdzenie_pacjenta_w_programie();
                if (czy_jest_pac_w_prog == 0)
                {
                    Dodaj_Pacjentów_Do_Programu();
                    Wyswietl_Pacjentów_Programu();
                }
                else { MessageBox.Show(string.Format("Wybrany Pacjent jest już przypisany do programu:\n{0}", program_nazwa_2)); }
            }
            else{ MessageBox.Show("Zbyt duża ilość osób"); }
            
            
        }

        private void BtN_Dodaj_Pacjenta_Do_Programu_Blacebo_Click(object sender, RoutedEventArgs e)
        {
            sprawdzenie_ilości_pacjentow_w_programie();
            if (ile_pac_w_programie < max_pac_w_programie)
            {
                Pobranie_PAC_ID_PROG_NAZWA();
                sprawdzenie_pacjenta_w_programie();
                if (czy_jest_pac_w_prog == 0)
                {
                    Dodaj_Pacjentów_Do_Programu_Placebo();
                    Wyswietl_Pacjentów_Programu();
                }
                else { MessageBox.Show(string.Format("Wybrany Pacjent jest już przypisany do programu:\n{0}", program_nazwa_2)); }
            }
            else { MessageBox.Show("Zbyt duża ilość osób"); }
        }

        private void BtN_Dodaj_Pacjenta_Click(object sender, RoutedEventArgs e)
        {
            DODAJ_PACJENTA dpac = new DODAJ_PACJENTA();
            NavigationService.Navigate(dpac);
        }
   
        private void BtN_Dodaj_Program_Click(object sender, RoutedEventArgs e)
        {
            DODAJ_PROGRAM dprog = new DODAJ_PROGRAM();
            NavigationService.Navigate(dprog);
        }

        private void BtN_Odśwież_Click(object sender, RoutedEventArgs e)
        {
            Wyswietl_Pacjentów_Programu();
        }
    }
}
