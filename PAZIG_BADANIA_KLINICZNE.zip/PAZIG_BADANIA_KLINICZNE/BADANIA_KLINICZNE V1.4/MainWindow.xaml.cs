﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using System.Data;
using System.IO;

namespace BADANIA_KLINICZNE_V1._4
{
    /// <summary>
    /// Logika interakcji dla klasy MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public string connection_string;
        public string adres_serwera;
        public MySqlConnection con;
        public string nazwa_bazy_danych;
        public string uzytkownik_bazy_danych;
        public string haslo_uzytkownika;
        public string port;
        public MainWindow()
        {
            InitializeComponent();
            Ustawienia_Polaczenia();
            Polaczenie();
        }

        public void Ustawienia_Polaczenia()
        {
            StreamReader SR = new StreamReader("USTAWIENIA_POŁĄCZENIA.txt");
            adres_serwera = SR.ReadLine();
            port = SR.ReadLine();
            nazwa_bazy_danych = SR.ReadLine();
            uzytkownik_bazy_danych = SR.ReadLine();
            haslo_uzytkownika = SR.ReadLine();
            SR.Close();
        }
        public void Polaczenie()
        {

            connection_string = string.Format("server={0}; port={1}; database={2}; user={3}; password={4};", adres_serwera, port, nazwa_bazy_danych, uzytkownik_bazy_danych, haslo_uzytkownika);
            con = new MySqlConnection(connection_string);
            con.Open();


        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Main.Content = new DODAJ_PACJENTA();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Main.Content = new DODAJ_PROGRAM();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Main.Content = new PACJENCI_PROGRAMU();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Main.Content = new DOPISZ_PACJENTA_DO_PROGRAMU();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            Main.Content = new SLOWNIKI();
        }
    }
}
