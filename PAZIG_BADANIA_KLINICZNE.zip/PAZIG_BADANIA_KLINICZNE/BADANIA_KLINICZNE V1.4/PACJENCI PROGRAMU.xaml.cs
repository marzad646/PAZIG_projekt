﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using System.Data;

namespace BADANIA_KLINICZNE_V1._4
{
    /// <summary>
    /// Logika interakcji dla klasy PACJENCI_PROGRAMU.xaml
    /// </summary>
    public partial class PACJENCI_PROGRAMU : Page
    {
        MainWindow m = new MainWindow();
        public string cmd_szukaj_programy;
        public string cmd_wyswietl_pacjentow_programu;
        public string cmd_szukaj_pomiary;
        public string cmd_szukaj_leki;
        public string program_nazwa;
        public string nr_pacjenta_w_programie;

        public string nazwa_pomiar_1;
        public string nazwa_pomiar_2;
        public string nazwa_pomiar_3;
        public string zmierzony_pomiar_1;
        public string zmierzony_pomiar_2;
        public string zmierzony_pomiar_3;
        public string data_pomiar_1;
        public string data_pomiar_2;
        public string data_pomiar_3;
        public string zmierzony_pomiar_1_opis;
        public string zmierzony_pomiar_2_opis;
        public string zmierzony_pomiar_3_opis;
        public string cmd_zapis_pomiar_1;
        public string cmd_zapis_pomiar_2;
        public string cmd_zapis_pomiar_3;

        public string nazwa_lek_1;
        public string nazwa_lek_2;
        public string nazwa_lek_3;
        public string podany_lek_1;
        public string podany_lek_2;
        public string podany_lek_3;
        public string data_podania_leku_1;
        public string data_podania_leku_2;
        public string data_podania_leku_3;
        public string podany_lek_1_opis;
        public string podany_lek_2_opis;
        public string podany_lek_3_opis;
        public string cmd_zapis_podania_leku_1;
        public string cmd_zapis_podania_leku_2;
        public string cmd_zapis_podania_leku_3;



        public PACJENCI_PROGRAMU()
        {
            InitializeComponent();
            Wczytaj_Programy();
        }


        public void Wczytaj_Programy() //LISTA ROZWIJALNA, ZASILANIE COMBOBOXA
        {
            CbX_PROGRAMY.Items.Clear();
            cmd_szukaj_programy = "SELECT NAZWA_PROG FROM `program` order by prog_id desc;";
            DataTable Slownik = new DataTable();
            MySqlCommand cmd = new MySqlCommand(cmd_szukaj_programy, m.con);
            MySqlDataReader czytnik = cmd.ExecuteReader();
            while (czytnik.Read())
            {
                string programy = czytnik.GetString(0);
                CbX_PROGRAMY.Items.Add(programy);

            }
            czytnik.Close();
            CbX_PROGRAMY.SelectedIndex = 0;


        }

        public void Wczytaj_Pomiary()// LISTY ROZWIJALNE Z POMIARÓW - ZASILANIE COMOBOXÓW Z POMIARAMI
        {
            program_nazwa = CbX_PROGRAMY.Text;
            CbX_PROGRAM_POMIARY_1.Items.Clear(); // CZYSTE LISTY ROZWIJALNE
            CbX_PROGRAM_POMIARY_2.Items.Clear();
            CbX_PROGRAM_POMIARY_3.Items.Clear();
            cmd_szukaj_pomiary = string.Format("SELECT nazwa_pom FROM `sl_pomiary` WHERE POM_ID in (select POM_ID from program_pomiary where PROG_ID = (SELECT PROG_ID FROM `program` WHERE NAZWA_PROG = '{0}')); ", program_nazwa);
            DataTable Slownik_Pomiary = new DataTable();
            MySqlCommand cmd_pomiary = new MySqlCommand(cmd_szukaj_pomiary, m.con);
            MySqlDataReader czytnik_pomiary = cmd_pomiary.ExecuteReader();
            while (czytnik_pomiary.Read())
            {
                string programy = czytnik_pomiary.GetString(0);
                CbX_PROGRAM_POMIARY_1.Items.Add(programy); //ZCZYTUJE I ZASILA Z TABELI POMIARY PROGRAMU
                CbX_PROGRAM_POMIARY_2.Items.Add(programy);
                CbX_PROGRAM_POMIARY_3.Items.Add(programy);

            }
            czytnik_pomiary.Close();
            CbX_PROGRAM_POMIARY_1.SelectedIndex = 0; //ZAWSZE 1 POMIAR MOŻLIWY 
            CbX_PROGRAM_POMIARY_2.SelectedIndex = 0;
            CbX_PROGRAM_POMIARY_3.SelectedIndex = 0;


        }

        public void Wczytaj_Leki() //ANALOGIA POWYŻEJ
        {
            program_nazwa = CbX_PROGRAMY.Text;
            CbX_PROGRAM_LEKI_1.Items.Clear();
            CbX_PROGRAM_LEKI_2.Items.Clear();
            CbX_PROGRAM_LEKI_3.Items.Clear();
            cmd_szukaj_leki = string.Format("SELECT nazwa_lek FROM `sl_leki` WHERE LEK_ID in (select LEK_ID from program_leki where PROG_ID = (SELECT PROG_ID FROM `program` WHERE NAZWA_PROG = '{0}')); ", program_nazwa);
            DataTable Slownik_Leki = new DataTable();
            MySqlCommand cmd_leki = new MySqlCommand(cmd_szukaj_leki, m.con);
            MySqlDataReader czytnik_leki = cmd_leki.ExecuteReader();
            while (czytnik_leki.Read())
            {
                string programy = czytnik_leki.GetString(0);
                CbX_PROGRAM_LEKI_1.Items.Add(programy);
                CbX_PROGRAM_LEKI_2.Items.Add(programy);
                CbX_PROGRAM_LEKI_3.Items.Add(programy);

            }
            czytnik_leki.Close();
            CbX_PROGRAM_LEKI_1.SelectedIndex = 0;
            CbX_PROGRAM_LEKI_2.SelectedIndex = 0;
            CbX_PROGRAM_LEKI_3.SelectedIndex = 0;


        }
        public void Wyswietl_Pacjentów_Programu() //ODŚWIEŻA SIĘ DATAGRID Z LEWEJ STRONY (Z PACJENTAMI)
        {
            
            cmd_wyswietl_pacjentow_programu = string.Format("SELECT CONCAT('Pacjent numer: ',' ',PAC_NR) as PACJENT FROM pacjenci_programu prg where prg.prog_id in (select prog_id from program where NAZWA_PROG = '{0}'); ", program_nazwa);
            DataTable Slownik = new DataTable();
            MySqlCommand cmd = new MySqlCommand(cmd_wyswietl_pacjentow_programu, m.con);
            MySqlDataReader czytnik = cmd.ExecuteReader();
            Slownik.Load(czytnik);
            DG_Pacjenci_Programu.ItemsSource = Slownik.DefaultView;
        }

        public void Wyswietl_Leki_Pacjentów_Programu() //ZASILANIE DATAGRIDÓW (UZUPEŁNIENIE ICH) Z LEKAMI
        {
            cmd_wyswietl_pacjentow_programu = string.Format("SELECT DATE_FORMAT(pl.data_podania,  \"%Y-%m-%d %H:%i:%S\") AS DATA, sl.NAZWA_LEK AS NAZWA, pl.dawka_leku AS DAWKA,  pl.opis_podania AS OPIS FROM `podanie_leku` pl join sl_leki sl on pl.lek_id = sl.LEK_ID where prog_id in (select prog_id from program where NAZWA_PROG = '{0}') and pac_id in (SELECT PAC_ID FROM `pacjenci_programu` where PAC_NR = '{1}' and PROG_ID in (select prog_id from program where NAZWA_PROG = '{0}')) order by pl.data_podania desc;", program_nazwa, nr_pacjenta_w_programie);
            DataTable Slownik_Leki = new DataTable();
            MySqlCommand cmd_leki = new MySqlCommand(cmd_wyswietl_pacjentow_programu, m.con);
            MySqlDataReader czytnik_leki = cmd_leki.ExecuteReader();
            Slownik_Leki.Load(czytnik_leki);
            DG_Podane_Leki.ItemsSource = Slownik_Leki.DefaultView;
        }

        public void Wyswietl_Pomiary_Pacjentów_Programu() //ZASILANIE DATAGRIDÓW (UZUPEŁNIENIE ICH) Z POMIARAMI
        {
            cmd_wyswietl_pacjentow_programu = string.Format("SELECT DATE_FORMAT(zmp.DATA_POMIARU,  \"%Y-%m-%d %H:%i:%S\") AS DATA, sp.NAZWA_POM AS NAZWA, zmp.WART_POMIARU AS WARTOŚĆ,  zmp.OPIS_POMIARU AS OPIS FROM zmierzone_pomiary zmp join sl_pomiary sp on zmp.pom_id=sp.POM_ID where prog_id in (select prog_id from program where NAZWA_PROG = '{0}') and pac_id in (SELECT PAC_ID FROM `pacjenci_programu` where PAC_NR = '{1}' and PROG_ID in (select prog_id from program where NAZWA_PROG = '{0}')) order by zmp.DATA_POMIARU desc;", program_nazwa, nr_pacjenta_w_programie);
            DataTable Slownik_Pomiary = new DataTable();
            MySqlCommand cmd_pomiary = new MySqlCommand(cmd_wyswietl_pacjentow_programu, m.con);
            MySqlDataReader czytnik_pomiary = cmd_pomiary.ExecuteReader();
            Slownik_Pomiary.Load(czytnik_pomiary);
            DG_Zmierzone_Pomiary.ItemsSource = Slownik_Pomiary.DefaultView;
        }

        public void zapis_danych()
        {
            nazwa_pomiar_1 = CbX_PROGRAM_POMIARY_1.Text;// TO CO WYBRANE Z LISTY ZAPISUJEMY DO ZMIENNEJ
            nazwa_pomiar_2 = CbX_PROGRAM_POMIARY_2.Text;
            nazwa_pomiar_3 = CbX_PROGRAM_POMIARY_3.Text;
            zmierzony_pomiar_1 = TxT_PROGRAM_POMIARY_1.Text;//Z POLA TEKSTOWEGO WPISANEGO RECZNIE
            zmierzony_pomiar_2 = TxT_PROGRAM_POMIARY_2.Text;
            zmierzony_pomiar_3 = TxT_PROGRAM_POMIARY_3.Text;
            data_pomiar_1 = Date_Picker_PROGRAM_POMIARY_1.Value.ToString();//POBRANIE DATY
            data_pomiar_2 = Date_Picker_PROGRAM_POMIARY_2.Value.ToString();
            data_pomiar_3 = Date_Picker_PROGRAM_POMIARY_3.Value.ToString();
            zmierzony_pomiar_1_opis = TxT_PROGRAM_POMIARY_1_OPIS_DODATKOWY.Text;// DODATKOWT OPIS DO ZMIENNEJ
            zmierzony_pomiar_2_opis = TxT_PROGRAM_POMIARY_2_OPIS_DODATKOWY.Text;
            zmierzony_pomiar_3_opis = TxT_PROGRAM_POMIARY_3_OPIS_DODATKOWY.Text;

            nazwa_lek_1 = CbX_PROGRAM_LEKI_1.Text;
            nazwa_lek_2 = CbX_PROGRAM_LEKI_2.Text;
            nazwa_lek_3 = CbX_PROGRAM_LEKI_3.Text;
            podany_lek_1 = TxT_PROGRAM_LEK_1.Text;
            podany_lek_2 = TxT_PROGRAM_LEK_2.Text;
            podany_lek_3 = TxT_PROGRAM_LEK_3.Text;
            data_podania_leku_1 = Date_Picker_PROGRAM_LEK_1.Value.ToString();
            data_podania_leku_2 = Date_Picker_PROGRAM_LEK_2.Value.ToString();
            data_podania_leku_3 = Date_Picker_PROGRAM_LEK_3.Value.ToString();
            podany_lek_1_opis = TxT_PROGRAM_LEK_1_OPIS_DODATKOWY.Text;
            podany_lek_2_opis = TxT_PROGRAM_LEK_2_OPIS_DODATKOWY.Text;
            podany_lek_3_opis = TxT_PROGRAM_LEK_3_OPIS_DODATKOWY.Text;

            cmd_zapis_pomiar_1 = string.Format("INSERT INTO `zmierzone_pomiary`(`ZM_POM_ID`, `PROG_ID`, `PAC_ID`, `POM_ID`, `WART_POMIARU`, `DATA_POMIARU`, `OPIS_POMIARU`) VALUES ((SELECT nvl((MAX(ZM_POM_ID)+1),'1') FROM `zmierzone_pomiary`  zm_pom),(select prog_id from program where NAZWA_PROG = '{0}'),(SELECT PAC_ID FROM `pacjenci_programu` where PAC_NR = '{1}' and PROG_ID in (select prog_id from program where NAZWA_PROG = '{0}')),(SELECT POM_ID FROM `sl_pomiary` WHERE NAZWA_POM = '{2}'),'{3}','{4}','{5}')", program_nazwa, nr_pacjenta_w_programie, nazwa_pomiar_1, zmierzony_pomiar_1, data_pomiar_1, zmierzony_pomiar_1_opis);
            cmd_zapis_pomiar_2 = string.Format("INSERT INTO `zmierzone_pomiary`(`ZM_POM_ID`, `PROG_ID`, `PAC_ID`, `POM_ID`, `WART_POMIARU`, `DATA_POMIARU`, `OPIS_POMIARU`) VALUES ((SELECT nvl((MAX(ZM_POM_ID)+1),'1') FROM `zmierzone_pomiary`  zm_pom),(select prog_id from program where NAZWA_PROG = '{0}'),(SELECT PAC_ID FROM `pacjenci_programu` where PAC_NR = '{1}' and PROG_ID in (select prog_id from program where NAZWA_PROG = '{0}')),(SELECT POM_ID FROM `sl_pomiary` WHERE NAZWA_POM = '{2}'),'{3}','{4}','{5}')", program_nazwa, nr_pacjenta_w_programie, nazwa_pomiar_2, zmierzony_pomiar_2, data_pomiar_2, zmierzony_pomiar_2_opis);
            cmd_zapis_pomiar_3 = string.Format("INSERT INTO `zmierzone_pomiary`(`ZM_POM_ID`, `PROG_ID`, `PAC_ID`, `POM_ID`, `WART_POMIARU`, `DATA_POMIARU`, `OPIS_POMIARU`) VALUES ((SELECT nvl((MAX(ZM_POM_ID)+1),'1') FROM `zmierzone_pomiary`  zm_pom),(select prog_id from program where NAZWA_PROG = '{0}'),(SELECT PAC_ID FROM `pacjenci_programu` where PAC_NR = '{1}' and PROG_ID in (select prog_id from program where NAZWA_PROG = '{0}')),(SELECT POM_ID FROM `sl_pomiary` WHERE NAZWA_POM = '{2}'),'{3}','{4}','{5}')", program_nazwa, nr_pacjenta_w_programie, nazwa_pomiar_3, zmierzony_pomiar_3, data_pomiar_3, zmierzony_pomiar_3_opis);

            //INSERTY DO POMIARÓW
            if (zmierzony_pomiar_1 != "" && data_pomiar_1 != "")// CZY POLE DO POMIARÓW I DATA SĄ WYPEŁNIONE, TO WTEDY ZAPISUJE WYNIKI
            {
                MySqlCommand cmd_zp_1 = new MySqlCommand(cmd_zapis_pomiar_1, m.con);
                cmd_zp_1.ExecuteNonQuery();
            }
            if (zmierzony_pomiar_2 != "" && data_pomiar_2 != "")
            {
                MySqlCommand cmd_zp_2 = new MySqlCommand(cmd_zapis_pomiar_2, m.con);
                cmd_zp_2.ExecuteNonQuery();
            }
            if (zmierzony_pomiar_3 != "" && data_pomiar_3 != "")
            {
                MySqlCommand cmd_zp_3 = new MySqlCommand(cmd_zapis_pomiar_3, m.con);
                cmd_zp_3.ExecuteNonQuery();
            }
            

            cmd_zapis_podania_leku_1 = string.Format("INSERT INTO `podanie_leku`(`POD_LEK_ID`, `PROG_ID`, `PAC_ID`, `LEK_ID`, `DAWKA_LEKU`, `DATA_PODANIA`, `OPIS_PODANIA`) VALUES ((SELECT nvl((MAX(POD_LEK_ID)+1),'1') FROM `podanie_leku`  zm_pom),(select prog_id from program where NAZWA_PROG = '{0}'),(SELECT PAC_ID FROM `pacjenci_programu` where PAC_NR = '{1}' and PROG_ID in (select prog_id from program where NAZWA_PROG = '{0}')),(SELECT LEK_ID FROM `sl_leki` WHERE NAZWA_LEK = '{2}'),'{3}','{4}','{5}')", program_nazwa, nr_pacjenta_w_programie, nazwa_lek_1, podany_lek_1, data_podania_leku_1, podany_lek_1_opis);
            cmd_zapis_podania_leku_2 = string.Format("INSERT INTO `podanie_leku`(`POD_LEK_ID`, `PROG_ID`, `PAC_ID`, `LEK_ID`, `DAWKA_LEKU`, `DATA_PODANIA`, `OPIS_PODANIA`) VALUES ((SELECT nvl((MAX(POD_LEK_ID)+1),'1') FROM `podanie_leku`  zm_pom),(select prog_id from program where NAZWA_PROG = '{0}'),(SELECT PAC_ID FROM `pacjenci_programu` where PAC_NR = '{1}' and PROG_ID in (select prog_id from program where NAZWA_PROG = '{0}')),(SELECT LEK_ID FROM `sl_leki` WHERE NAZWA_LEK = '{2}'),'{3}','{4}','{5}')", program_nazwa, nr_pacjenta_w_programie, nazwa_lek_2, podany_lek_2, data_podania_leku_2, podany_lek_2_opis);
            cmd_zapis_podania_leku_3 = string.Format("INSERT INTO `podanie_leku`(`POD_LEK_ID`, `PROG_ID`, `PAC_ID`, `LEK_ID`, `DAWKA_LEKU`, `DATA_PODANIA`, `OPIS_PODANIA`) VALUES ((SELECT nvl((MAX(POD_LEK_ID)+1),'1') FROM `podanie_leku`  zm_pom),(select prog_id from program where NAZWA_PROG = '{0}'),(SELECT PAC_ID FROM `pacjenci_programu` where PAC_NR = '{1}' and PROG_ID in (select prog_id from program where NAZWA_PROG = '{0}')),(SELECT LEK_ID FROM `sl_leki` WHERE NAZWA_LEK = '{2}'),'{3}','{4}','{5}')", program_nazwa, nr_pacjenta_w_programie, nazwa_lek_3, podany_lek_3, data_podania_leku_3, podany_lek_3_opis);

            if (podany_lek_1 != "" && data_podania_leku_1 != "")
            {
                MySqlCommand cmd_zpl_1 = new MySqlCommand(cmd_zapis_podania_leku_1, m.con);
                cmd_zpl_1.ExecuteNonQuery();
            }
            if (podany_lek_2 != "" && data_podania_leku_2 != "")
            {
                MySqlCommand cmd_zpl_2 = new MySqlCommand(cmd_zapis_podania_leku_2, m.con);
                cmd_zpl_2.ExecuteNonQuery();
            }
            if (podany_lek_3 != "" && data_podania_leku_3 != "")
            {
                MySqlCommand cmd_zpl_3 = new MySqlCommand(cmd_zapis_podania_leku_3, m.con);
                cmd_zpl_3.ExecuteNonQuery();
            }

        }

        public void Czyszczenie_Pol()
        {
            TxT_PROGRAM_POMIARY_1.Text = "";
            TxT_PROGRAM_POMIARY_2.Text = "";
            TxT_PROGRAM_POMIARY_3.Text = "";
            Date_Picker_PROGRAM_POMIARY_1.Text = "";
            Date_Picker_PROGRAM_POMIARY_2.Text = "";
            Date_Picker_PROGRAM_POMIARY_3.Text = "";
            TxT_PROGRAM_POMIARY_1_OPIS_DODATKOWY.Text = "";
            TxT_PROGRAM_POMIARY_2_OPIS_DODATKOWY.Text = "";
            TxT_PROGRAM_POMIARY_3_OPIS_DODATKOWY.Text = "";
            TxT_PROGRAM_LEK_1.Text = "";
            TxT_PROGRAM_LEK_2.Text = "";
            TxT_PROGRAM_LEK_3.Text = "";
            Date_Picker_PROGRAM_LEK_1.Text = "";
            Date_Picker_PROGRAM_LEK_2.Text = "";
            Date_Picker_PROGRAM_LEK_3.Text = "";
            TxT_PROGRAM_LEK_1_OPIS_DODATKOWY.Text = "";
            TxT_PROGRAM_LEK_2_OPIS_DODATKOWY.Text = "";
            TxT_PROGRAM_LEK_3_OPIS_DODATKOWY.Text = "";
        }
      

        private void BtN_ZAPISZ_Click(object sender, RoutedEventArgs e)
        {
            if (DG_Pacjenci_Programu.SelectedItem != null) //JEŻELI PACJENT WYBRANY, TO ROBIE TEGO IFA
            {
                program_nazwa = CbX_PROGRAMY.Text;
                DataRowView numer_wiersza_pacjent_programu = (DataRowView)DG_Pacjenci_Programu.SelectedItem;
                nr_pacjenta_w_programie = numer_wiersza_pacjent_programu.Row.ItemArray[0].ToString().Remove(0, 16);
                zapis_danych();
                Czyszczenie_Pol();
                Wyswietl_Leki_Pacjentów_Programu();
                Wyswietl_Pomiary_Pacjentów_Programu();
            }
            else { MessageBox.Show("Brak wybranego pacjenta"); } //PAXJENT NIE WYBRANY - MESSEAGE BOX OBŁĘDZIE
        }

        private void Button_Click_Odśwież(object sender, RoutedEventArgs e) //NA NOWO SIĘ ZASILA DATAGRID POD PACJENTA
        {
            if (DG_Pacjenci_Programu.SelectedItem != null)//TO SAMO CO WYŻEJ
            {
                program_nazwa = CbX_PROGRAMY.Text;
                DataRowView numer_wiersza_pacjent_programu = (DataRowView)DG_Pacjenci_Programu.SelectedItem;
                nr_pacjenta_w_programie = numer_wiersza_pacjent_programu.Row.ItemArray[0].ToString().Remove(0, 16);
                Wyswietl_Leki_Pacjentów_Programu();
                Wyswietl_Pomiary_Pacjentów_Programu();
            }
            else { MessageBox.Show("Brak wybranego pacjenta"); }
        }

        
        private void BTN_WCZYTAJ_Click(object sender, RoutedEventArgs e)
        {
            program_nazwa = CbX_PROGRAMY.Text;
            Wyswietl_Pacjentów_Programu();
            Wczytaj_Pomiary();
            Wczytaj_Leki();
            Wyswietl_Leki_Pacjentów_Programu();
            Wyswietl_Pomiary_Pacjentów_Programu();
        }
    }
}
