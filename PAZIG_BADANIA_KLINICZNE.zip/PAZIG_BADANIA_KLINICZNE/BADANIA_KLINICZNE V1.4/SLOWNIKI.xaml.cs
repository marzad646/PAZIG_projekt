﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using System.Data;

namespace BADANIA_KLINICZNE_V1._4
{
    /// <summary>
    /// Logika interakcji dla klasy SLOWNIKI.xaml
    /// </summary>
    public partial class SLOWNIKI : Page
    {
        MainWindow m = new MainWindow();
        public string cmd_szukaj_slownik;
        public string cmd_dodaj_slownik;
        public string rodzaj_slownika;
        public string kod_lub_nazwa;
        public string dodaj_kod;
        public string dodaj_nazwa;
        public string dodaj_jednostka;
        public string dodaj_opis;
        public SLOWNIKI()
        {
            InitializeComponent();
        }

        
        private  void Wczytaj_Slownik()
        {
            rodzaj_slownika = CbX_SLOWNIK.Text;
            kod_lub_nazwa = "%"+TxT_KOD_LUB_NAZWA.Text.ToUpper()+"%";
            if (rodzaj_slownika == "Słownik Leków")
            {
                cmd_szukaj_slownik = string.Format("SELECT LEK_KOD as \"KOD\", NAZWA_LEK as \"NAZWA LEKU\", OPIS_LEK as \"PEŁNY OPIS LEKU\"  FROM sl_leki WHERE LEK_KOD LIKE '{0}' or NAZWA_LEK like '{0}';", kod_lub_nazwa);
            }
            else if (rodzaj_slownika == "Słownik Pomiarów")
            {
                cmd_szukaj_slownik = string.Format("SELECT POM_KOD as \"KOD\", NAZWA_POM as \"NAZWA POMIARU\", JEDNOSTKA_POM as \"JEDNOSTKA\", OPIS_POM as \"OPIS METODY POMIARU\" FROM sl_pomiary WHERE NAZWA_POM like '{0}' or POM_KOD LIKE '{0}';",kod_lub_nazwa);
            }
            DataTable Slownik = new DataTable();
            MySqlCommand cmd = new MySqlCommand(cmd_szukaj_slownik, m.con);
            MySqlDataReader czytnik = cmd.ExecuteReader();
            Slownik.Load(czytnik);
            DATA_GRID_SLOWNIK.ItemsSource = Slownik.DefaultView;
        }

        private void Dodaj_Do_Slownika()
        {
            dodaj_kod = TxT_KOD.Text.ToUpper();
            dodaj_nazwa = TxT_NAZWA_PELNA.Text.ToUpper();
            dodaj_jednostka = TxT_JEDNOSTA.Text;
            dodaj_opis = TxT_OPIS.Text.ToUpper();
            if (rodzaj_slownika == "Słownik Leków")
            {
                cmd_dodaj_slownik = string.Format("INSERT INTO `sl_leki`(`LEK_ID`, `LEK_KOD`, `NAZWA_LEK`, `OPIS_LEK`) VALUES ((SELECT nvl((MAX(LEK_ID)+1),'1') FROM `sl_leki`  lek),'{0}','{1}','{2}')", dodaj_kod,dodaj_nazwa,dodaj_opis);
            }
            else if (rodzaj_slownika == "Słownik Pomiarów")
            {
                cmd_dodaj_slownik = string.Format("INSERT INTO `sl_pomiary`(`POM_ID`, `POM_KOD`, `NAZWA_POM`, `JEDNOSTKA_POM`, `OPIS_POM`) VALUES ((SELECT nvl((MAX(POM_ID)+1),'1') FROM `sl_pomiary`  pom),'{0}','{1}','{2}','{3}')", dodaj_kod,dodaj_nazwa,dodaj_jednostka,dodaj_opis);
            }
            MySqlCommand cmd2 = new MySqlCommand(cmd_dodaj_slownik, m.con);
            cmd2.ExecuteNonQuery();

        }
        private void Czyszczenie()
        {
            TxT_KOD.Text = "";
            TxT_NAZWA_PELNA.Text = "";
            TxT_JEDNOSTA.Text = "";
            TxT_OPIS.Text = "";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Wczytaj_Slownik();
        }

        private void BtN_DODAJ_DO_SLOWNIK_Click(object sender, RoutedEventArgs e)
        {
            Dodaj_Do_Slownika();
            Czyszczenie();
            Wczytaj_Slownik();
            

        }
    }
}
